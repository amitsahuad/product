package com.eCommerce.Repository;

import com.eCommerce.dto.ProductBasicInfoDTO;
import com.eCommerce.entity.ProductDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductDetailsRepository extends JpaRepository<ProductDetails,Integer> {


  /* @Query("select productDetails from ProductDetails productDetails where productDetails.productName= ?1")
    List<ProductDetails> findBasicDetailsByProductName(String productName);*/
  @Query(value="select * from  product_details  where offer_of_the_day=true",nativeQuery = true)
  List<ProductDetails> findAllOfferOfTheDay();

  //@Query(value="select * from  product_details  where product_name like %?1%",nativeQuery = true)
  List<ProductDetails> findAllByProductName(String productName);
}
