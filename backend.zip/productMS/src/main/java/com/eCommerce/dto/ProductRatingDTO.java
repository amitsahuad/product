package com.eCommerce.dto;

import com.eCommerce.entity.ProductRating;
import org.modelmapper.ModelMapper;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class ProductRatingDTO {
    private Integer id;

    @NotNull(message = "Please Provide Product Id")
    private Integer productDetailsId;

    @NotNull(message = "Please Provide User Id")
    private Integer userId;

    @NotNull(message = "Please Enter the rating")
    @Max(value = 5 , message = "Please provide rating between 1 to 5")
    @Min(value = 0,message = "Please provide rating between 1 to 5")
    private Integer rating;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getProductDetailsId() {
        return productDetailsId;
    }

    public void setProductDetailsId(Integer productDetailsId) {
        this.productDetailsId = productDetailsId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public ProductRating convertToEntity(ProductRatingDTO productRatingDTO) {
        ModelMapper modelMapper = new ModelMapper();
        ProductRating productRating = modelMapper.map(productRatingDTO, ProductRating.class);
        return productRating;
    }
}
