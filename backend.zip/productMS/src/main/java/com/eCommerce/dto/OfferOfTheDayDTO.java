package com.eCommerce.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class OfferOfTheDayDTO {

    @NotNull(message = "Please Provide Product Id")
    private Integer productDetailsId;

    @Max(value = 100 , message = "Please provide discount between 0 to 100")
    @Min(value = 0,message = "Please provide discount between 0 to 100")
    @NotNull(message = "Please Provide Product Id")
    private Double extraDiscount;

    public Integer getProductDetailsId() {
        return productDetailsId;
    }

    public void setProductDetailsId(Integer productDetailsId) {
        this.productDetailsId = productDetailsId;
    }

    public Double getExtraDiscount() {
        return extraDiscount;
    }

    public void setExtraDiscount(Double extraDiscount) {
        this.extraDiscount = extraDiscount;
    }
}
