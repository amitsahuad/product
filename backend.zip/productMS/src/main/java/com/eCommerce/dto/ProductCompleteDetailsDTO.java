package com.eCommerce.dto;

import com.eCommerce.entity.ProductDetails;
import org.modelmapper.ModelMapper;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.List;

public class ProductCompleteDetailsDTO {

    private Integer id;

    @NotNull(message = "Please Enter the Product Category Id ")
    @Max(value = 6 , message = "Please provide Category Id between 1 to 6")
    @Min(value = 1,message = "Please provide Category Id between 1 to 6")
    private Integer productCategoryId;

    @NotNull(message = "Please Provide Seller Id")
    private Integer sellerId;

    @NotNull(message = "Please Provide Product Name")
    private String productName;

    @Min(value = 0,message = "Price should be greater than 0")
    @NotNull(message = "Please Provide Product Price")
    private Double productPrice;

    @NotNull(message = "Please Provide Product Description")
    private String productDescription;


    @Max(value = 100 , message = "Please provide discount between 0 to 100")
    @Min(value = 0,message = "Please provide discount between 0 to 100")
    @NotNull(message = "Please Provide Product Id")
    private Double productDiscount;

    @Min(value = 0,message = "Quantity should be greater than 0")
    @NotNull(message = "Please Provide quantity")
    private Integer productQuantity;

    private Double productRating;

    private List<ProductReviewDTO> productReviewList;

    private List<ProductBasicInfoDTO> otherSellerBasicInfo;
     //offer of the day

    @NotNull(message = "Please Provide image Url")
    private String imageUrl;


    public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getProductCategoryId() {
        return productCategoryId;
    }

    public void setProductCategoryId(Integer productCategoryId) {
        this.productCategoryId = productCategoryId;
    }

    public Integer getSellerId() {
        return sellerId;
    }

    public void setSellerId(Integer sellerId) {
        this.sellerId = sellerId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(Double productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public Double getProductDiscount() {
        return productDiscount;
    }

    public void setProductDiscount(Double productDiscount) {
        this.productDiscount = productDiscount;
    }

    public Integer getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(Integer productQuantity) {
        this.productQuantity = productQuantity;
    }

    public List<ProductReviewDTO> getProductReviewList() {
        return productReviewList;
    }

    public void setProductReviewList(List<ProductReviewDTO> productReviewList) {
        this.productReviewList = productReviewList;
    }

    public List<ProductBasicInfoDTO> getOtherSellerBasicInfo() {
        return otherSellerBasicInfo;
    }

    public void setOtherSellerBasicInfo(List<ProductBasicInfoDTO> otherSellerBasicInfo) {
        this.otherSellerBasicInfo = otherSellerBasicInfo;
    }

    public Double getProductRating() {
        return productRating;
    }

    public void setProductRating(Double productRating) {
        this.productRating = productRating;
    }

    public ProductDetails convertToEntity(ProductCompleteDetailsDTO productCompleteDetailsDTO) {
        ModelMapper modelMapper = new ModelMapper();
        ProductDetails productDetails = modelMapper.map(productCompleteDetailsDTO, ProductDetails.class);
        return productDetails;
    }
}
