package com.eCommerce.dto;

import com.eCommerce.entity.ProductRating;
import com.eCommerce.entity.ProductReview;
import org.modelmapper.ModelMapper;

import javax.validation.constraints.NotNull;

public class ProductReviewDTO {


    @NotNull(message = "Please Provide User Id")
    private Integer userId;

    @NotNull(message = "Please Provide Review")
    private String review;

    @NotNull(message = "Please Provide Product Id")
    private Integer productDetailsId;


    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public Integer getProductDetailsId() {
        return productDetailsId;
    }

    public void setProductDetailsId(Integer productDetailsId) {
        this.productDetailsId = productDetailsId;
    }

    public ProductReview convertToEntity(ProductReviewDTO productReviewDTO) {
        ModelMapper modelMapper = new ModelMapper();
        ProductReview productReview = modelMapper.map(productReviewDTO, ProductReview.class);
        return productReview;
    }
}
