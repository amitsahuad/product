package com.eCommerce.controller;


import com.eCommerce.dto.ProductCompleteDetailsDTO;
import com.eCommerce.dto.ProductRatingDTO;
import com.eCommerce.entity.ProductDetails;
import com.eCommerce.entity.ProductRating;
import com.eCommerce.services.interfaces.IProductRatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/product/rating")
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class ProductRatingController {

    @Autowired
    IProductRatingService productRatingService;


    @PostMapping("/createProductRating")
    public ProductRatingDTO createProductRating(@Valid  @RequestBody ProductRatingDTO productRatingDTO){
        return productRatingService.createProductRating(productRatingDTO);
    }
}
