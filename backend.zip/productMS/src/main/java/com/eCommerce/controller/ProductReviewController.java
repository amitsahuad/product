package com.eCommerce.controller;

import com.eCommerce.dto.ProductRatingDTO;
import com.eCommerce.dto.ProductReviewDTO;
import com.eCommerce.services.interfaces.IProductReviewService;
import com.eCommerce.services.interfaces.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/product/review")
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class ProductReviewController {

    @Autowired
    IProductReviewService productReviewService;

    @PostMapping("/createProductReview")
    public ProductReviewDTO createProductReview(@Valid @RequestBody ProductReviewDTO productReviewDTO){
        return productReviewService.createProductReview(productReviewDTO);
    }
}
