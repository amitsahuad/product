package com.eCommerce.controller;


import com.eCommerce.dto.ProductBasicInfoDTO;
import com.eCommerce.dto.ProductCompleteDetailsDTO;
import com.eCommerce.entity.ProductDetails;
import com.eCommerce.services.interfaces.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class ProductDetailsController {

    @Autowired
    private IProductService productService;

    @PostMapping("/createProductDetails")
    public ProductDetails createProductDetails(@Valid @RequestBody ProductCompleteDetailsDTO productCompleteDetailsDTO){
        return productService.createProductDetails(productCompleteDetailsDTO);
    }

    @GetMapping("/getProductDetailsByProductId/{productId}")
    public ProductCompleteDetailsDTO getProductDetailsByProductId(@PathVariable Integer productId){
        return productService.getCompleteDetailsByProductId(productId);
    }

    @GetMapping("/getBasicProductDetailsByProductName/{productName}")
    public List<ProductBasicInfoDTO> getBasicProductDetailsByProductName(@PathVariable String productName){
        return productService.getProductsBasicDetailsByName(productName);
    }
}
