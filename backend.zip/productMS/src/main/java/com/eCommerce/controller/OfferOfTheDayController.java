package com.eCommerce.controller;

import com.eCommerce.dto.OfferOfTheDayDTO;
import com.eCommerce.dto.ProductBasicInfoDTO;
import com.eCommerce.services.interfaces.IOfferOfTheDayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/product/offer")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class OfferOfTheDayController {

    @Autowired
    IOfferOfTheDayService offerOfTheDayService;

    @PostMapping("/createOfferOfTheDay")
    public OfferOfTheDayDTO createOfferOfTheDay(@Valid  @RequestBody OfferOfTheDayDTO offerOfTheDayDTO){
        return offerOfTheDayService.createOfferOfTheDay(offerOfTheDayDTO);
    }

    @GetMapping("/getAllOfferOfTheDay")
    public List<ProductBasicInfoDTO> getAllOfferOfTheDay(){
        return offerOfTheDayService.getAllOfferOfTheDay();
    }
}
