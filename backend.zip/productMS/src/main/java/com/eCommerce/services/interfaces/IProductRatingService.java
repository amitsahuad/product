package com.eCommerce.services.interfaces;

import com.eCommerce.dto.ProductRatingDTO;
import com.eCommerce.entity.ProductRating;

public interface IProductRatingService {

    ProductRatingDTO createProductRating(ProductRatingDTO productRatingDTO);

}
