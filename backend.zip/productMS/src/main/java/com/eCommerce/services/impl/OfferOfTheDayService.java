package com.eCommerce.services.impl;

import com.eCommerce.Repository.ProductDetailsRepository;
import com.eCommerce.dto.OfferOfTheDayDTO;
import com.eCommerce.dto.ProductBasicInfoDTO;
import com.eCommerce.entity.ProductDetails;
import com.eCommerce.services.interfaces.IOfferOfTheDayService;
import com.eCommerce.utilities.exception.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service("offerOfTheDayService")
public class OfferOfTheDayService implements IOfferOfTheDayService {


    @Autowired
    ProductDetailsRepository productDetailsRepository;


    @Override
    public OfferOfTheDayDTO createOfferOfTheDay(OfferOfTheDayDTO offerOfTheDayDTO) {
        Optional<ProductDetails> productDetails = productDetailsRepository.findById(offerOfTheDayDTO.getProductDetailsId());
        if(!productDetails.isPresent()) {
            throw new ValidationException(HttpStatus.NOT_FOUND,"Product Id Not Found");

        }
            productDetails.get().setOfferOfTheDay(true);
            productDetails.get().setExtraDiscount(offerOfTheDayDTO.getExtraDiscount());
            productDetailsRepository.save(productDetails.get());


        return  offerOfTheDayDTO;

    }

    @Override
    public List<ProductBasicInfoDTO> getAllOfferOfTheDay() {
      List<ProductDetails> productDetailsList =productDetailsRepository.findAllOfferOfTheDay();

      if(productDetailsList.size()<=0)
          throw new  ValidationException(HttpStatus.NOT_FOUND,"No Offers For Today");
      List<ProductBasicInfoDTO> productBasicInfoDTOList=new ArrayList<>();
        for (ProductDetails productDetails :productDetailsList) {
            productDetails.setProductDiscount(productDetails.getExtraDiscount());
            productBasicInfoDTOList.add(productDetails.convertToProductBasicInfoDto(productDetails));
        }
      return productBasicInfoDTOList;
    }
}
