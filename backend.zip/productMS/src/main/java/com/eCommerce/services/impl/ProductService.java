package com.eCommerce.services.impl;
import com.eCommerce.Repository.ProductCategoryRepository;
import com.eCommerce.Repository.ProductDetailsRepository;
import com.eCommerce.Repository.ProductRatingRepository;
import com.eCommerce.Repository.ProductReviewRepository;
import com.eCommerce.dto.ProductBasicInfoDTO;
import com.eCommerce.dto.ProductCompleteDetailsDTO;
import com.eCommerce.dto.ProductReviewDTO;
import com.eCommerce.entity.ProductCategory;
import com.eCommerce.entity.ProductDetails;
import com.eCommerce.entity.ProductRating;
import com.eCommerce.entity.ProductReview;
import com.eCommerce.services.interfaces.IProductService;
import com.eCommerce.utilities.exception.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service("productService")
public class ProductService implements IProductService {

    @Autowired
    ProductDetailsRepository productDetailsRepository;

    @Autowired
    ProductReviewRepository productReviewRepository;

    @Autowired
    ProductRatingRepository productRatingRepository;

    @Autowired
    ProductCategoryRepository productCategoryRepository;


    @Override
    public ProductCompleteDetailsDTO getCompleteDetailsByProductId(Integer productId) {
       Optional<ProductDetails> productDetails = productDetailsRepository.findById(productId);

       if(!productDetails.isPresent())
            throw new ValidationException(HttpStatus.NOT_FOUND,"Product Id Not Found");


        ProductCompleteDetailsDTO productCompleteDetailsDTO= productDetails.get().convertToDto(productDetails.get());

        if(productDetails.get().getOfferOfTheDay()) {
            productCompleteDetailsDTO.setProductDiscount(productDetails.get().getExtraDiscount());
        }

        List<ProductReview> productReviewList = productReviewRepository.findAllByProductDetailsId(productId);
        List<ProductReviewDTO> productReviewDTOList =productReviewList.stream().map(productReview->productReview.convertToDto(productReview)).collect(Collectors.toList());
        productCompleteDetailsDTO.setProductReviewList(productReviewDTOList);

        List<ProductDetails> productDetailsList=productDetailsRepository.findAllByProductName(productDetails.get().getProductName());
        List<ProductBasicInfoDTO> productBasicInfoDTOList=new ArrayList<>();
        for (ProductDetails productDetails1 :productDetailsList) {
            if(productDetails1.getOfferOfTheDay()){
                productDetails1.setProductDiscount(productDetails1.getExtraDiscount());
            }
            productBasicInfoDTOList.add(productDetails1.convertToProductBasicInfoDto(productDetails1));
        }
        productCompleteDetailsDTO.setOtherSellerBasicInfo(productBasicInfoDTOList);

        List<Integer> ratingList = productRatingRepository.findRatingByProductDetailsId(productId);
        Double avgRating = getAvgRatingOfProduct(ratingList);
        productCompleteDetailsDTO.setProductRating(avgRating);
        return productCompleteDetailsDTO;
    }

    @Override
    public List<ProductBasicInfoDTO> getProductsBasicDetailsByName(String productName) {
        List<ProductDetails> productDetailsList = productDetailsRepository.findAllByProductName(productName);
        if(productDetailsList.size()<=0)
            throw new ValidationException(HttpStatus.NOT_FOUND,"Product Not Found");

        List<ProductBasicInfoDTO> productBasicInfoDTOList=new ArrayList<>();
        for (ProductDetails productDetails :productDetailsList) {

            if(productDetails.getOfferOfTheDay()){
                productDetails.setProductDiscount(productDetails.getExtraDiscount());
            }
            productBasicInfoDTOList.add(productDetails.convertToProductBasicInfoDto(productDetails));
        }
         return productBasicInfoDTOList;
    }
    @Override
    public ProductDetails createProductDetails(ProductCompleteDetailsDTO productCompleteDetailsDTO) {
        Optional<ProductCategory> productCategory = productCategoryRepository.findById(productCompleteDetailsDTO.getProductCategoryId());
        if(!productCategory.isPresent())
            throw new ValidationException(HttpStatus.NOT_FOUND,"Category Id Not Found");


        ProductDetails productDetails =productCompleteDetailsDTO.convertToEntity(productCompleteDetailsDTO);
        return productDetailsRepository.save(productDetails);
    }


    public  Double getAvgRatingOfProduct(List<Integer> ratingList){
        Integer sumOfRatings = ratingList.stream().reduce(0,Integer::sum);
        Double avgOfRatings = sumOfRatings/(ratingList.size()*1.0);
        return avgOfRatings;
    }

}
