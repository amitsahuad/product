package com.eCommerce.services.interfaces;


import com.eCommerce.dto.ProductRatingDTO;
import com.eCommerce.dto.ProductReviewDTO;
import com.eCommerce.entity.ProductReview;

public interface IProductReviewService {

    ProductReviewDTO createProductReview(ProductReviewDTO productReviewDTO);

}
