package com.eCommerce.services.interfaces;


import com.eCommerce.dto.OfferOfTheDayDTO;
import com.eCommerce.dto.ProductBasicInfoDTO;

import java.util.List;

public interface IOfferOfTheDayService {

    OfferOfTheDayDTO createOfferOfTheDay(OfferOfTheDayDTO offerOfTheDayDTO);

    List<ProductBasicInfoDTO> getAllOfferOfTheDay();

}
