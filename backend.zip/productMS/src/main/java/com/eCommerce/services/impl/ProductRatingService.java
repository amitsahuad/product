package com.eCommerce.services.impl;

import com.eCommerce.Repository.ProductDetailsRepository;
import com.eCommerce.Repository.ProductRatingRepository;
import com.eCommerce.dto.ProductRatingDTO;
import com.eCommerce.entity.ProductDetails;
import com.eCommerce.entity.ProductRating;
import com.eCommerce.services.interfaces.IProductRatingService;
import com.eCommerce.utilities.exception.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service("productRatingService")
public class ProductRatingService implements IProductRatingService {

    @Autowired
    ProductRatingRepository productRatingRepository;

    @Autowired
    ProductDetailsRepository productDetailsRepository;

    @Override
    public ProductRatingDTO createProductRating(ProductRatingDTO productRatingDTO) {
        Optional<ProductDetails> productDetails=productDetailsRepository.findById(productRatingDTO.getProductDetailsId());
        if(!productDetails.isPresent())
                throw new ValidationException(HttpStatus.NOT_FOUND,"Product Id Not Found");

        ProductRating productRating = productRatingDTO.convertToEntity(productRatingDTO);
        ProductRating productRating1 = productRatingRepository.save(productRating);
        ProductRatingDTO productRatingDTO1=productRating1.convertToDTO(productRating1);
        return productRatingDTO1;



    }
}
