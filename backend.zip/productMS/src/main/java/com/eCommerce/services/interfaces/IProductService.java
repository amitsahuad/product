package com.eCommerce.services.interfaces;

import com.eCommerce.dto.ProductBasicInfoDTO;
import com.eCommerce.dto.ProductCompleteDetailsDTO;
import com.eCommerce.entity.ProductDetails;

import java.util.List;

public interface IProductService {

    ProductCompleteDetailsDTO getCompleteDetailsByProductId(Integer productId);
    List<ProductBasicInfoDTO> getProductsBasicDetailsByName(String name );
    ProductDetails   createProductDetails(ProductCompleteDetailsDTO productCompleteDetailsDTO);


}
