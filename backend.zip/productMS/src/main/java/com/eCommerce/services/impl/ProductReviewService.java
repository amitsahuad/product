package com.eCommerce.services.impl;


import com.eCommerce.Repository.ProductDetailsRepository;
import com.eCommerce.Repository.ProductReviewRepository;
import com.eCommerce.dto.ProductReviewDTO;
import com.eCommerce.entity.ProductDetails;
import com.eCommerce.entity.ProductReview;
import com.eCommerce.services.interfaces.IProductReviewService;
import com.eCommerce.utilities.exception.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service("productReviewService")
public class ProductReviewService implements IProductReviewService {
    @Autowired
    ProductReviewRepository productReviewRepository;

    @Autowired
    ProductDetailsRepository productDetailsRepository;

    @Override
    public ProductReviewDTO createProductReview(ProductReviewDTO productReviewDTO) {
        Optional<ProductDetails> productDetails=productDetailsRepository.findById(productReviewDTO.getProductDetailsId());

        if(!productDetails.isPresent())
            throw new ValidationException(HttpStatus.NOT_FOUND,"Product Id Not Found");

        ProductReview productReview = productReviewDTO.convertToEntity(productReviewDTO);

        ProductReview productReview1 = productReviewRepository.save(productReview);

        ProductReviewDTO productReviewDTO1 = productReview.convertToDto(productReview1);
        return productReviewDTO1;
    }
}
