package com.eCommerce.entity;


import com.eCommerce.dto.ProductCompleteDetailsDTO;
import com.eCommerce.dto.ProductRatingDTO;
import org.modelmapper.ModelMapper;

import javax.persistence.*;

@Entity(name="product_rating")
public class ProductRating {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;

    @Column(name="product_details_id")
    private Integer productDetailsId;

    @Column(name="user_id")
    private Integer userId;

    @Column(name="rating")
    private Integer rating;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getProductDetailsId() {
        return productDetailsId;
    }

    public void setProductDetailsId(Integer productDetailsId) {
        this.productDetailsId = productDetailsId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public ProductRatingDTO convertToDTO(ProductRating productRating) {
        ModelMapper modelMapper = new ModelMapper();
        ProductRatingDTO productRatingDTO = modelMapper.map(productRating, ProductRatingDTO.class);
        return productRatingDTO;
    }

}
