package com.eCommerce.entity;

import com.eCommerce.dto.ProductCompleteDetailsDTO;
import com.eCommerce.dto.ProductReviewDTO;
import org.modelmapper.ModelMapper;

import javax.persistence.*;

@Entity(name="product_review")
public class ProductReview {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;

    @Column(name="product_details_id")
    private Integer productDetailsId;

    @Column(name="user_id")
    private Integer userId;

    @Column(name="review")
    private String review;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getProductDetailsId() {
        return productDetailsId;
    }

    public void setProductDetailsId(Integer productDetailsId) {
        this.productDetailsId = productDetailsId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public ProductReviewDTO convertToDto(ProductReview productReview) {
        ModelMapper modelMapper = new ModelMapper();
        ProductReviewDTO productReviewDTO = modelMapper.map(productReview, ProductReviewDTO.class);
        return productReviewDTO;


    }

}
