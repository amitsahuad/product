package com.eCommerce.entity;
import com.eCommerce.dto.ProductBasicInfoDTO;
import com.eCommerce.dto.ProductCompleteDetailsDTO;
import org.hibernate.annotations.ColumnDefault;
import org.modelmapper.ModelMapper;

import javax.persistence.*;

@Entity(name="product_details")
public class ProductDetails {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;

    @Column(name="product_category_id")
    private Integer productCategoryId;

    @Column(name="seller_id")
    private Integer sellerId;

    @Column(name="product_name")
    private String productName;

    @Column(name="product_price")
    private Double productPrice;

    @Column(name="product_description")
    private String productDescription;

    @Column(name="product_discount")
    private Double productDiscount;

    @Column(name="product_quantity")
    private Integer productQuantity;


    @Column(name="extra_discount")
    private Double extraDiscount;


    @Column(name="offer_of_the_day")
    private Boolean offerOfTheDay;
    
    @Column(name="image_url")
    private String imageUrl;

    public ProductDetails() {
        this.offerOfTheDay = false;
        this.extraDiscount = 0.0;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getProductCategoryId() {
        return productCategoryId;
    }

    public void setProductCategoryId(Integer productCategoryId) {
        this.productCategoryId = productCategoryId;
    }

    public Integer getSellerId() {
        return sellerId;
    }

    public void setSellerId(Integer sellerId) {
        this.sellerId = sellerId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(Double productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public Double getProductDiscount() {
        return productDiscount;
    }

    public void setProductDiscount(Double productDiscount) {
        this.productDiscount = productDiscount;
    }

    public Integer getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(Integer productQuantity) {
        this.productQuantity = productQuantity;
    }

    public Double getExtraDiscount() {
        return extraDiscount;
    }

    public void setExtraDiscount(Double extraDiscount) {
        this.extraDiscount = extraDiscount;
    }

    public Boolean getOfferOfTheDay() {
        return offerOfTheDay;
    }

    public void setOfferOfTheDay(Boolean offerOfTheDay) {
        this.offerOfTheDay = offerOfTheDay;
    }

    public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public ProductCompleteDetailsDTO convertToDto(ProductDetails productDetails) {
        ModelMapper modelMapper = new ModelMapper();
        ProductCompleteDetailsDTO productCompleteDetailsDTO = modelMapper.map(productDetails, ProductCompleteDetailsDTO.class);
        return productCompleteDetailsDTO;


    }

    public ProductBasicInfoDTO convertToProductBasicInfoDto(ProductDetails productDetails) {
        ModelMapper modelMapper = new ModelMapper();
        ProductBasicInfoDTO productBasicInfoDTO = modelMapper.map(productDetails, ProductBasicInfoDTO.class);
        return productBasicInfoDTO;


    }


}
