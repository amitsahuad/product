package com.infydu.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfyDuDiscoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
