export interface ProductDetails {
    id: number;
    productName: string;
    productPrice: number;
    productDiscount: number;
    sellerId: number;
    imageUrl: string;
}
