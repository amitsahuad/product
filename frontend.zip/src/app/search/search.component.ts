import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { SearchService } from '../search.service';
import { ProductDetails } from './ProductDetails';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {


  searchName: any
  constructor(private route: ActivatedRoute, private service: SearchService,private fb: FormBuilder) {
    this.route.params.subscribe(params => this.searchName = params.id);
    console.log(this.searchName)

  }
  
  product! : FormGroup

  productList: any
  ngOnInit(): void {
    this.product = this.fb.group({
      id: ['',[]]
    })
    console.log(this.product.value.id)

    this.service.getDeails(this.searchName).subscribe(res => {
      this.productList = res;
      console.log(this.productList)
    }
    )
  }
  getProductInfo(id:number){
    console.log(id);

  }



}
