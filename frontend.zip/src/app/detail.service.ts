import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Details } from './Details';

@Injectable({
  providedIn: 'root'
})
export class DetailService {
url="http://localhost:9000/product/getProductDetailsByProductId/"
  constructor(private http:HttpClient) { }

  getAllDetails(id:number):Observable<Details>{
    return this.http.get<Details>(this.url+id);
  }
}
