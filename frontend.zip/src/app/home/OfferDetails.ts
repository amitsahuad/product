export interface OfferDetails {
    id: number;
    productName: string;
    productPrice: number;
    productDiscount: number;
    sellerId: number;
    imageUrl: string;
}
