import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { HomeService } from '../home.service';
import { OfferDetails } from './OfferDetails'; 

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  constructor(private fb: FormBuilder, private router: Router, private service: HomeService) { }
  homeForm!: FormGroup


  OfferOfTheDayList: OfferDetails[] = []
  ngOnInit(): void {
    this.homeForm = this.fb.group({
      search: ['', []]
    })

    this.service.getAllOfferOfTheDay().subscribe(res=>this.OfferOfTheDayList=res)

  }
  searchQuery() {
    console.log(this.homeForm.value.search)

    
    this.router.navigateByUrl(this.homeForm.value.search)
  }
}
