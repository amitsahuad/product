export interface Review{
    productDetailsId:number;
    userId:number;
    review:string;
}