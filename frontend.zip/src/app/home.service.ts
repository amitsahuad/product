
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { OfferDetails } from './home/OfferDetails';
import { Observable } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
const httpOptions = {
  header: new HttpHeaders({
    "Access-Control-Allow_Origin": "*"
  })
};
@Injectable({
  providedIn: 'root'
})

export class HomeService {

  constructor(private http: HttpClient) { }

  url = "http://localhost:9000/product/offer/getAllOfferOfTheDay"


  getAllOfferOfTheDay(): Observable<OfferDetails[]> {
    return this.http.get<OfferDetails[]>(this.url).
    pipe(tap(data => console.log('Data Fetched:' + JSON.stringify(data))))

    
  }
}
