import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ProductinfoComponent } from './productinfo/productinfo.component'; 
import { SearchComponent } from './search/search.component';

const routes: Routes = [
  {path:":id" , component:SearchComponent },
  {path: "info" , component:ProductinfoComponent },
  {path: "**" , component:HomeComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

