import { Review } from "./home/Review";
import { ProductDetails } from "./search/ProductDetails";

export interface Details{
id:number;
productCategoryId: number;
sellerId: number;
productName:string;
productPrice: number;
productDescription: string;
productDiscount: number;
productQuantity: number;
productRating:number;
productReviewList: Review[];
otherSellerBasicInfo:ProductDetails[];
imageUrl:string;
}