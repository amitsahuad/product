import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { Observable } from 'rxjs';
import { ProductDetails } from './search/ProductDetails';
@Injectable({
  providedIn: 'root'
})
export class SearchService {

  constructor(private http:HttpClient) { }
  url="http://localhost:9000/product/getBasicProductDetailsByProductName/"

  getDeails(id:any): Observable<ProductDetails[]>{
   return this.http.get<ProductDetails[]>(this.url+id)
  }
}